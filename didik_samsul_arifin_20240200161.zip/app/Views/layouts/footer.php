<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>2025 &copy; <a href="https://github.com/zuramai/mazer/">mazer </a></p>
        </div>
        <div class="float-end">
            <p>
                
                <span class="text-danger"><i class="bi bi-heart-fill icon-mid"></i></span>
                by <a href="https://google.com">DIDIK SAMSUL ARIFIN</a>
            </p>
        </div>
    </div>
</footer>
 <script src="/assets/static/js/components/dark.js"></script>
    <script src="/assets/extensions/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="/assets/compiled/js/app.js"></script>
    <script src="/assets/static/js/pages/sweetalert2.js"></script>
    
</body>

</html>