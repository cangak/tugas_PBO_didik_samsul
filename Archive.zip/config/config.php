<?php
// konfigurasi databse dan base URL, bisa ditambah suatu saat nanti
return [
  'db_host' => 'localhost',
  'db_name' => 'tugas_web_dinamis',
  'db_user' => 'root',
  'db_pass' => 'master10',
  'base_url' => 'http://didik_samsul_refactor.test', 
];
