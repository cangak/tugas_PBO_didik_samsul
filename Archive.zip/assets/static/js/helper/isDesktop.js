export default (window) => window.innerWidth > 1200;
